  $(function() {
    $('#simple_sketch').sketch();
  });